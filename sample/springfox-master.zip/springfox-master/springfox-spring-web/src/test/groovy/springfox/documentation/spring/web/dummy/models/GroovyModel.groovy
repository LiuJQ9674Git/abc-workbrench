package springfox.documentation.spring.web.dummy.models

class GroovyModel {
  String stringProp

  GroovyModel(String stringProp) {
    this.stringProp = stringProp
  }

  String getStringProp() {
    return stringProp
  }

  void setStringProp(String stringProp) {
    this.stringProp = stringProp
  }
}
