# springfox-demos
Springfox demo applications 


#IDE
First build
```
./gradlew idea
```
